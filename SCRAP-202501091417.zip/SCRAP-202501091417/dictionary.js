console.log("Loaded: dictionary.js");

// dictionary.js
// dictionary.js の演算子定義を更新
window.ops = {
    '+': (stack) => {
        if (stack.length < 2) throw new Error("Insufficient items on stack for '+'");
        const b = stack.pop();
        const a = stack.pop();
        stack.push(a + b);
        console.log(`Executed '+': ${a} + ${b} = ${a + b}, Current stack: [${stack}]`);
    },
    '-': (stack) => {
        if (stack.length < 2) throw new Error("Insufficient items on stack for '-'");
        const b = stack.pop();
        const a = stack.pop();
        stack.push(a - b);
        console.log(`Executed '-': ${a} - ${b} = ${a - b}, Current stack: [${stack}]`);
    },
    '*': (stack) => {
        if (stack.length < 2) throw new Error("Insufficient items on stack for '*'");
        const b = stack.pop();
        const a = stack.pop();
        stack.push(a * b);
        console.log(`Executed '*': ${a} * ${b} = ${a * b}, Current stack: [${stack}]`);
    },
    '/': (stack) => {
        if (stack.length < 2) throw new Error("Insufficient items on stack for '/'");
        const b = stack.pop();
        const a = stack.pop();
        if (b === 0) throw new Error("Division by zero");
        stack.push(a / b);
        console.log(`Executed '/': ${a} / ${b} = ${a / b}, Current stack: [${stack}]`);
    },
    'CLEAR': (stack) => {
        stack.length = 0;
        console.log(`Executed 'CLEAR', Current stack is empty`);
    },
    'DUP': (stack) => {
        if (stack.length < 1) throw new Error("Insufficient items on stack for 'DUP'");
        const a = stack[stack.length - 1];
        stack.push(a);
        console.log(`Executed 'DUP': duplicated ${a}, Current stack: [${stack}]`);
    }
};


window.initializeDB = () => {
    console.log("Database initialized (simulation)");
};

window.saveCustomWord = (name, definition) => {
    console.log('saveCustomWord called with:', { name, definition });
    try {
        window.ops[name] = (stack, depth = 0) => {
            console.log(`Executing custom word: ${name} with definition: ${definition}`);
            const MAX_DEPTH = 100;
            if (depth > MAX_DEPTH) {
                throw new Error(`Custom word "${name}" exceeded maximum recursion depth`);
            }

            const tokens = definition.split(/\s+/);
            console.log(`Tokens for ${name}:`, tokens);

            tokens.forEach(token => {
                console.log(`Processing token: ${token}`);
                if (window.ops[token]) {
                    console.log(`Executing operation: ${token}`);
                    window.ops[token](stack, depth + 1);
                } else {
                    const numValue = parseFloat(token);
                    if (!isNaN(numValue)) {
                        console.log(`Pushing number: ${numValue}`);
                        stack.push(numValue);
                    } else {
                        console.log(`Pushing token as is: ${token}`);
                        stack.push(token);
                    }
                }
            });
            console.log(`Finished executing custom word ${name}, Stack:`, stack);
        };
        console.log(`Successfully defined custom word: ${name}`);
    } catch (error) {
        console.error(`Error in saveCustomWord for ${name}:`, error);
        throw error;
    }
};

