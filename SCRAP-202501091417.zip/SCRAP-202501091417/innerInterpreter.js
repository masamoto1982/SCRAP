console.log("Loaded: innerInterpreter.js");

// innerInterpreter.js
window.interpret = (stack, token) => {
    if (window.ops[token]) {
        try {
            window.ops[token](stack);
        } catch (error) {
            console.error(`Error interpreting token "${token}": ${error.message}`);
        }
    } else {
        stack.push(isNaN(parseFloat(token)) ? token : parseFloat(token));
    }
};