console.log("Loaded: main.js");

// main.js
window.onload = () => {
    window.initializeDB();

    window.deleteCustomWord = (wordName) => {
    console.log(`Attempting to delete custom word: ${wordName}`);
    try {
        // カスタムワードの存在確認
        if (!window.ops[wordName]) {
            throw new Error(`Word "${wordName}" not found`);
        }

        // ビルトインワードの削除を防止
        const builtInWords = ['+', '-', '*', '/', 'DUP', 'CLEAR'];
        if (builtInWords.includes(wordName)) {
            throw new Error(`Cannot delete built-in word: ${wordName}`);
        }

        // カスタムワードの削除
        delete window.ops[wordName];

        // UIからボタンを削除
        const customWordsContainer = document.getElementById('customWordsContainer');
        const buttons = customWordsContainer.getElementsByClassName('word-button');
        for (let button of buttons) {
            if (button.textContent === wordName) {
                button.remove();
                break;
            }
        }

        console.log(`Successfully deleted custom word: ${wordName}`);
        return true;
    } catch (error) {
        console.error(`Error deleting custom word: ${error.message}`);
        return false;
    }
};

window.handleDeleteWord = (event) => {
    if (event.key === "Enter") {
        const wordToDelete = event.target.value.trim();
        console.log(`Attempting to delete word via keyboard: ${wordToDelete}`);
        if (window.deleteCustomWord(wordToDelete)) {
            event.target.value = '';
        }
    }
};

window.handleDeleteDrop = (event) => {
    event.preventDefault();
    const rawData = event.dataTransfer.getData('text/plain');
    console.log(`Handling delete drop with data: ${rawData}`);
    
    try {
        const data = JSON.parse(rawData);
        const wordToDelete = data.type === 'custom-word' ? data.value : null;
        
        if (wordToDelete) {
            console.log(`Attempting to delete dropped word: ${wordToDelete}`);
            if (window.deleteCustomWord(wordToDelete)) {
                document.getElementById('deleteWordInput').value = '';
            }
        }
    } catch (error) {
        console.error('Error processing delete drop:', error);
    }
};

window.drag = (e) => {
    const target = e.target;
    if (target.classList.contains('word-button')) {
        let data;
        if (target.closest('#customWordsContainer')) {
            // カスタムワードの場合
            data = {
                type: 'custom-word',
                value: target.textContent
            };
        } else if (target.dataset.index !== undefined) {
            // スタックアイテムの場合
            data = {
                type: 'stack-item',
                stackLabel: target.closest('.stackContainer')?.id === 'stackDContainer' ? 'Stack_D' : 'Stack_R',
                index: parseInt(target.dataset.index),
                value: target.textContent
            };
        } else {
            // 通常のワードボタンの場合
            data = {
                type: 'word',
                value: target.textContent
            };
        }
        e.dataTransfer.setData('text/plain', JSON.stringify(data));
        console.log(`Dragging with data:`, data);
    }
};



   window.handleWordDefinitionKeypress = (event, inputId) => {
    console.log(`Key pressed in ${inputId}:`, event.key);
    if (event.key === "Enter") {
        if (inputId === 'wordName') {
            console.log('Moving focus to wordDefinition');
            document.getElementById('wordDefinition').focus();
        } else if (inputId === 'wordDefinition') {
            console.log('Moving focus to wordDescription');
            document.getElementById('wordDescription').focus();
        } else {
            console.log('Attempting to define word');
            window.defineWord();
        }
    }
};

    window.defineWord = () => {
    try {
        const name = document.getElementById('wordName').value.trim();
        const definition = document.getElementById('wordDefinition').value.trim();
        const description = document.getElementById('wordDescription').value.trim();
        
        console.log('Attempting to define custom word:', {
            name: name,
            definition: definition,
            description: description
        });

        if (!name) {
            throw new Error('Word name is required');
        }
        if (!definition) {
            throw new Error('Word definition is required');
        }

        // 予約語チェック
        if (window.ops[name]) {
            throw new Error(`Cannot redefine built-in word: ${name}`);
        }

        // カスタムワードの定義
        console.log('Calling saveCustomWord with:', name, definition);
        window.saveCustomWord(name, definition);

        // カスタムワードボタンの作成
        const customWordsContainer = document.getElementById('customWordsContainer');
        if (!customWordsContainer) {
            throw new Error('Custom words container not found');
        }

        const wordButton = document.createElement('button');
        wordButton.className = 'word-button';
        wordButton.textContent = name;
        wordButton.draggable = true;
        wordButton.ondragstart = (event) => window.drag(event);
        if (description) {
            wordButton.title = description;
        }

        console.log('Adding new word button to container:', wordButton);
        customWordsContainer.appendChild(wordButton);

        // 入力フィールドをクリア
        document.getElementById('wordName').value = '';
        document.getElementById('wordDefinition').value = '';
        document.getElementById('wordDescription').value = '';

        console.log('Custom word defined successfully:', name);

    } catch (error) {
        console.error('Error defining custom word:', error);
        // エラーメッセージをユーザーに表示する場合はここに追加
    }
};


   window.runAllStacks = () => {
    const executeStack = (stack, label) => {
        if (stack.length === 0) return;  // 空のスタックは処理しない

        const workingStack = [...stack];
        const executionStack = [];

        try {
            // スタックの内容を処理
            while (workingStack.length > 0) {
                const token = workingStack[0];
                console.log(`Processing token: ${token} in ${label}`);

                if (!isNaN(parseFloat(token))) {
                    // 数値の場合
                    executionStack.push(parseFloat(token));
                    workingStack.shift();
                } else if (window.ops[token]) {
                    // 演算子の場合
                    console.log(`Executing operator: ${token} with stack: [${executionStack}]`);
                    window.ops[token](executionStack);
                    workingStack.shift();
                } else {
                    // 未知のトークンの場合
                    console.log(`Unknown token encountered: ${token} in ${label}`);
                    workingStack.shift();
                }
            }

            // 実行結果を元のスタックに反映
            stack.length = 0;
            executionStack.forEach(item => stack.push(item));

        } catch (error) {
            console.error(`Error executing ${label}: ${error.message}`);
        }
    };

    // 両方のスタックを独立して処理
    executeStack(window.Stack_D, 'Stack_D');
    executeStack(window.Stack_R, 'Stack_R');

    // 表示を更新
    window.refreshStackDisplay('Stack_D');
    window.refreshStackDisplay('Stack_R');
};



    window.handleStackInput = (event, stackName) => {
        if (event.key === "Enter") {
            const value = event.target.value.trim();
            if (value) {
                const stack = stackName === 'D' ? window.Stack_D : window.Stack_R;
                stack.push(isNaN(parseFloat(value)) ? value : parseFloat(value));
                window.refreshStackDisplay(stackName === 'D' ? 'Stack_D' : 'Stack_R');
                event.target.value = '';
            }
        }
    };

    window.allowDrop = window.allowDrop;
    window.drag = window.drag;
    window.dropToStack = window.dropToStack;

    window.refreshStackDisplay('Stack_D');
    window.refreshStackDisplay('Stack_R');
};