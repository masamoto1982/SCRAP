console.log("Loaded: outerInterpreter.js");

// outerInterpreter.js
window.parseInput = (input, stack) => {
    const tokens = input.trim().split(/\s+/);
    tokens.forEach(token => window.interpret(stack, token));
};