console.log("Loaded: repl.js");

// repl.js
window.Stack_D = [];
window.Stack_R = [];

window.refreshStackDisplay = (label) => {
    const container = document.getElementById(label === 'Stack_D' ? 'stackDContainer' : 'stackRContainer');
    const stack = label === 'Stack_D' ? window.Stack_D : window.Stack_R;

    container.innerHTML = '';
    if (stack.length === 0) {
        const placeholder = document.createElement('div');
        placeholder.className = 'stack-placeholder';
        placeholder.textContent = 'Stack is empty';
        container.appendChild(placeholder);
    }

    stack.forEach((item, index) => {
        const btn = document.createElement('button');
        btn.className = 'word-button';
        btn.textContent = item;
        btn.dataset.index = index;

        if (index === stack.length - 1) {
            btn.draggable = true;
            btn.ondragstart = (event) => window.drag(event);
        } else {
            btn.draggable = false;
            btn.classList.add('faded-button');
        }

        container.appendChild(btn);
    });
};

window.allowDrop = (e) => {
    e.preventDefault();
};

window.drag = (e) => {
    const target = e.target;
    if (target.classList.contains('word-button') && !target.classList.contains('faded-button')) {
        // ワードボタンの場合、そのテキストをドラッグデータとして設定
        if (target.dataset.index !== undefined) {
            // スタックアイテムの場合
            const stackLabel = target.closest('.stackContainer')?.id === 'stackDContainer' ? 'Stack_D' : 'Stack_R';
            const data = {
                type: 'stack-item',
                stackLabel: stackLabel,
                index: parseInt(target.dataset.index),
                value: target.textContent
            };
            e.dataTransfer.setData('text/plain', JSON.stringify(data));
            console.log(`Dragging stack item: ${JSON.stringify(data)}`);
        } else {
            // 通常のワードボタンの場合
            e.dataTransfer.setData('text/plain', JSON.stringify({
                type: 'word',
                value: target.textContent
            }));
            console.log(`Dragging word button: ${target.textContent}`);
        }
    }
};

window.dropToStack = (e, which) => {
    e.preventDefault();
    const rawData = e.dataTransfer.getData('text/plain');
    console.log(`Dropped data to stack: ${rawData}`);

    try {
        const parsedData = JSON.parse(rawData);
        const targetStack = which === 'D' ? window.Stack_D : window.Stack_R;

        if (parsedData.type === 'stack-item') {
            const sourceStack = parsedData.stackLabel === 'Stack_D' ? window.Stack_D : window.Stack_R;
            const value = sourceStack.splice(parsedData.index, 1)[0];
            targetStack.push(value);
        } else if (parsedData.type === 'word' || parsedData.type === 'custom-word') {
            targetStack.push(parsedData.value);
        }
    } catch (error) {
        console.error('Error processing drop to stack:', error);
    }

    window.refreshStackDisplay('Stack_D');
    window.refreshStackDisplay('Stack_R');
};

